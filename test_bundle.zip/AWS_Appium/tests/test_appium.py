import os
from selenium.webdriver.common.by import By
import unittest
from appium import webdriver
from appium.webdriver.common.mobileby import MobileBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import time
import subprocess


class MyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        desired_caps = {
            'platformName': 'Android',
            "deviceName": cls.get_android_platformName(),
            "platformVersion": cls.get_android_version(),
            'appPackage': 'com.joyreading.wehear',
            'appActivity': 'com.joyreading.wehear.main.view.activity.ProtolcalActivity',
            'automationName': 'UiAutomator2'
        }
        cls.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
        cls.wait = WebDriverWait(cls.driver, 10)

    @staticmethod
    def get_android_version():
        version = os.popen("adb shell getprop ro.build.version.release").read().strip()
        return version

    @staticmethod
    def get_android_platformName():
        platformName = os.popen("adb shell getprop ro.product.model").read().strip()
        return platformName

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    def test_open_protocal_activity(self):
        # 关闭隐私弹窗
        try:
            self.driver.find_element(By.ID, "com.joyreading.wehear:id/tv_agree")
        except NoSuchElementException as msg:
            print(u"隐私协议弹窗不存在%s" % msg)
        else:
            self.driver.find_element(By.ID, "com.joyreading.wehear:id/tv_agree").click()

        # 关闭定向跳转播放器
        time.sleep(20)
        try:
            self.driver.find_element(By.ID, "com.joyreading.wehear:id/play_view")
        except NoSuchElementException as msg:
            print(u"自然新增跳播放器不存在%s" % msg)
        else:
            self.driver.find_element(By.ID, "com.joyreading.wehear:id/iv_close").click()
            time.sleep(2)
            self.driver.keyevent(4)  # 点击Back键
            print("关闭播放器")

        # 关闭启动弹窗
        time.sleep(3)
        try:
            self.driver.find_element(By.ID, "com.joyreading.wehear:id/iv_ad_image")
        except NoSuchElementException as msg:
            print(u"启动广告弹窗不存在%s" % msg)
        else:
            self.driver.find_element(By.ID, "com.joyreading.wehear:id/tv_close").click()  # 关闭启动弹窗

        self.driver.find_element(By.ID, "com.joyreading.wehear:id/iv_discover").click()

        monkey_command = "adb shell monkey -p com.joyreading.wehear -v -v -v -s %random% --throttle 300 --pct-motion 0 --ignore-crashes --ignore-native-crashes --ignore-timeouts --monitor-native-crashes 1000"
        subprocess.run(monkey_command, shell=True)


if __name__ == '__main__':
    unittest.main()

